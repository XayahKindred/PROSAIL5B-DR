function Jout=Jfunc2(k,l,t)
Jout=(1.-exp(-(k+l)*t))./(k+l);
